/*
 Navicat Premium Dump SQL

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80400 (8.4.0)
 Source Host           : localhost:3306
 Source Schema         : inventory-management

 Target Server Type    : MySQL
 Target Server Version : 80400 (8.4.0)
 File Encoding         : 65001

 Date: 31/12/2024 10:14:19
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ly_in_out_records
-- ----------------------------
DROP TABLE IF EXISTS `ly_in_out_records`;
CREATE TABLE `ly_in_out_records`  (
  `Bound_id` int NOT NULL AUTO_INCREMENT COMMENT '单号',
  `Bound_product` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '商品',
  `Bound_number` double NULL DEFAULT NULL COMMENT '数量',
  `unit_of_quantity` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '数量单位',
  `IN_OR_OUT` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '出or入库',
  `Bound_date` date NULL DEFAULT NULL COMMENT '时间',
  `Bound_Operator` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '操作员',
  `Bound_wastage` double NULL DEFAULT NULL COMMENT '损耗',
  PRIMARY KEY (`Bound_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 115 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ly_in_out_records
-- ----------------------------
INSERT INTO `ly_in_out_records` VALUES (101, '苹果', 10, 'KG', '出库', '2024-12-01', 'GQW', 0);
INSERT INTO `ly_in_out_records` VALUES (102, '香蕉', 15, 'KG', '入库', '2024-11-11', 'GQW', 0);
INSERT INTO `ly_in_out_records` VALUES (103, '西瓜', 20, 'KG', '出库', '0024-10-01', 'GQW', 0);
INSERT INTO `ly_in_out_records` VALUES (104, '梨子', 20, 'KG', '入库', '2024-12-12', 'GQW', 0);
INSERT INTO `ly_in_out_records` VALUES (105, '芭乐', 10, 'kg', '出库', '2024-12-04', 'GQW', 0);
INSERT INTO `ly_in_out_records` VALUES (106, '青枣', 100, 'KG', '入库', '2024-12-06', 'GQW', 0);
INSERT INTO `ly_in_out_records` VALUES (109, 'iPhone15', 20, '个', '出库', '2024-12-21', 'ADMIN', 0);
INSERT INTO `ly_in_out_records` VALUES (114, '苹果', 20, NULL, '入库', '2024-12-30', 'ADMIN', 20.5);

-- ----------------------------
-- Table structure for ly_purchase
-- ----------------------------
DROP TABLE IF EXISTS `ly_purchase`;
CREATE TABLE `ly_purchase`  (
  `purchase_id` int NOT NULL AUTO_INCREMENT COMMENT '采购ID',
  `supplier_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '供应商名',
  `purchase_date` date NOT NULL COMMENT '采购日期',
  `purchase_product` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '采购商品',
  `purchase_number` double NOT NULL COMMENT '采购数量',
  `unit_price` decimal(10, 2) NOT NULL COMMENT '采购单价',
  `total_price` decimal(15, 2) GENERATED ALWAYS AS ((`purchase_number` * `unit_price`)) STORED COMMENT '采购总价' NULL,
  `status` enum('待完成','已完成','作废','已入库') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '待完成' COMMENT '采购状态',
  `purchase_unit` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '采购单位',
  PRIMARY KEY (`purchase_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ly_purchase
-- ----------------------------
INSERT INTO `ly_purchase` VALUES (1, 'ASP', '2024-08-24', '苹果', 20, 2.30, DEFAULT, '已入库', '每500克');
INSERT INTO `ly_purchase` VALUES (2, 'WSP', '2024-08-24', '香蕉', 20, 2.50, DEFAULT, '作废', '每500克');
INSERT INTO `ly_purchase` VALUES (3, 'TTP', '2024-08-24', '西瓜', 20, 1.20, DEFAULT, '已入库', '每500克');
INSERT INTO `ly_purchase` VALUES (4, 'FTP', '2024-08-26', '小果子', 30, 2.10, DEFAULT, '已完成', '每500克');
INSERT INTO `ly_purchase` VALUES (5, 'STP', '2024-10-20', 'iPad', 30, 5000.00, DEFAULT, '已完成', '个');
INSERT INTO `ly_purchase` VALUES (6, 'ASP', '2024-11-11', '苹果', 40.5, 3.20, DEFAULT, '已入库', '每500克');

-- ----------------------------
-- Table structure for ly_supplier
-- ----------------------------
DROP TABLE IF EXISTS `ly_supplier`;
CREATE TABLE `ly_supplier`  (
  `Supplier_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '供货商名',
  `Supplier_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系方式',
  `Supplier_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系地址',
  `Supplier_BL` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '供货商营业执照',
  `ID` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ly_supplier
-- ----------------------------
INSERT INTO `ly_supplier` VALUES ('ASP', '123', '123', '123', 1);
INSERT INTO `ly_supplier` VALUES ('FTP', '234', '234', '234', 2);
INSERT INTO `ly_supplier` VALUES ('STP', '456', '456', '456', 3);
INSERT INTO `ly_supplier` VALUES ('TTP', '12344565', '21342142345', '124332', 4);

-- ----------------------------
-- Table structure for ly_user
-- ----------------------------
DROP TABLE IF EXISTS `ly_user`;
CREATE TABLE `ly_user`  (
  `User_id` bigint NOT NULL AUTO_INCREMENT COMMENT '账号ID',
  `User_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '账户名',
  `User_password` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '账户密码',
  `User_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户联系电话',
  `permission` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`User_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1008 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ly_user
-- ----------------------------
INSERT INTO `ly_user` VALUES (1001, 'GQW', '123456', '11223344556', 'ADMIN');
INSERT INTO `ly_user` VALUES (1002, 'WYP', '123456', '11223344556', 'USER');
INSERT INTO `ly_user` VALUES (1003, 'LJH', '123456', '11223344556', 'USER');
INSERT INTO `ly_user` VALUES (1004, 'LDM', '123456', '11223344556', 'USER');
INSERT INTO `ly_user` VALUES (1005, 'ZYC', '123456', '12345678915', 'USER');
INSERT INTO `ly_user` VALUES (1006, 'LY', '123456', '44664138840', 'ADMIN');
INSERT INTO `ly_user` VALUES (1007, '112', '123', '456789', 'ADMIN');

-- ----------------------------
-- Table structure for ly_warehouse
-- ----------------------------
DROP TABLE IF EXISTS `ly_warehouse`;
CREATE TABLE `ly_warehouse`  (
  `Product_id` int NOT NULL AUTO_INCREMENT COMMENT '商品ID',
  `Product_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '商品名',
  `Product_category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '商品类别',
  `Product_purchase_price` double NULL DEFAULT NULL COMMENT '商品进价',
  `Product_selling_price` double NULL DEFAULT NULL COMMENT '商品售价',
  `Pricing_unit` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '售卖方式',
  `Product_quantity` int NULL DEFAULT NULL COMMENT '库存量',
  `Unit_of_quantity` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '库存单位',
  `Product_supplier` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '商品供应商',
  PRIMARY KEY (`Product_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 112 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ly_warehouse
-- ----------------------------
INSERT INTO `ly_warehouse` VALUES (101, '苹果', '水果', 2.3, 4.3, '斤', -60, 'KG', 'ASP');
INSERT INTO `ly_warehouse` VALUES (102, '香蕉', '水果', 2.6, 3.2, '斤', 35, 'KG', 'ASP');
INSERT INTO `ly_warehouse` VALUES (106, '西瓜', '水果', 1.2, 2.5, '斤', 18, 'KG', 'ASP');
INSERT INTO `ly_warehouse` VALUES (107, 'ipad', '电子产品', 3000, 3200, '个', 500, '个', 'ASP');
INSERT INTO `ly_warehouse` VALUES (108, '华为笔记本', '电子产品', 4000, 4500, '个', 200, '个', 'FTP');
INSERT INTO `ly_warehouse` VALUES (109, '华硕笔记本', '电子产品', 6000, 6500, '个', 300, '个', 'FTP');
INSERT INTO `ly_warehouse` VALUES (110, 'iPone15', '电子产品', 7000, 7500, '个', 500, '个', 'FTP');

-- ----------------------------
-- Procedure structure for demo_searchUser
-- ----------------------------
DROP PROCEDURE IF EXISTS `demo_searchUser`;
delimiter ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `demo_searchUser`(a varchar(50),b varchar(50))
BEGIN
	DECLARE v_sql varchar(200);
     set v_sql=concat('select * from demo_user where ',a,'=\'',b,'\'');
     SET @sql = v_sql;
     PREPARE sl FROM @sql;
     EXECUTE sl;
     DEALLOCATE PREPARE sl;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
