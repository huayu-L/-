package com.example.ly_jxc;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Pair;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class SupplierController {

    //退出按钮
    @FXML
    private Button ExitButton;
    @FXML
    private void handleExitButtonAction() {
        Stage stage = (Stage) ExitButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Management-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private TableView<Supplier> supplierTable;
    @FXML
    private TableColumn<Supplier, String> supplierName;
    @FXML
    private TableColumn<Supplier, String> supplierAddress;
    @FXML
    private TableColumn<Supplier, String> supplierPhone;
    @FXML
    private TableColumn<Supplier, String> supplierBL;

    @FXML
    private TableView<Warehouse> tableView;
    @FXML
    private TableColumn<Warehouse, String> warehouseName;

    @FXML
    private Button QueryButton;
    @FXML
    private Button RefreshButton;


    List<Supplier> supplierList = new ArrayList<>();
    List<Warehouse> warehouseList = new ArrayList<>();

    //数据库连接信息
    private static final String DB_URL = "jdbc:mysql://localhost:3306/inventory-management?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASS = "123456789";

    @FXML
    public void initialize() {
        supplierName.setCellValueFactory(new PropertyValueFactory<>("name"));
        supplierPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        supplierAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        supplierBL.setCellValueFactory(new PropertyValueFactory<>("BL"));

        warehouseName.setCellValueFactory(new PropertyValueFactory<>("name"));

        loadSupplierData();

        ObservableList<Supplier> supplierObservableList = FXCollections.observableArrayList(supplierList);
        supplierTable.setItems(supplierObservableList);
        RefreshButton.setOnAction(event -> loadSupplierData());

        ObservableList<Warehouse> warehouseObservableList = FXCollections.observableArrayList(warehouseList);
        tableView.setItems(warehouseObservableList);

        QueryButton.setOnAction(event -> performQuery());
    }

    private void loadSupplierData() {
        String sql = "SELECT Supplier_name, Supplier_phone, Supplier_address, Supplier_BL FROM ly_supplier";
        try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql)) {

            supplierList.clear();
            while (resultSet.next()) {
                Supplier supplier = new Supplier();
                supplier.setName(resultSet.getString("Supplier_name"));
                supplier.setPhone(resultSet.getString("Supplier_phone"));
                supplier.setAddress(resultSet.getString("Supplier_address"));
                supplier.setBL(resultSet.getString("Supplier_BL"));
                supplierList.add(supplier);
            }

            ObservableList<Supplier> supplierObservableList = FXCollections.observableArrayList(supplierList);
            supplierTable.setItems(supplierObservableList); // 重新设置数据
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //查询按钮
    @FXML
    private TextField supplierNameField;
    private void performQuery(){
        String name = supplierNameField.getText().trim();
        String sql = "SELECT Product_name FROM ly_warehouse WHERE Product_supplier = ?";
        try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
            PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            ResultSet resultSet = statement.executeQuery();
            warehouseList.clear();
            while (resultSet.next()) {
                Warehouse warehouse = new Warehouse();
                warehouse.setName(resultSet.getString("Product_name"));
                warehouseList.add(warehouse);
            }
            ObservableList<Warehouse> warehouseObservableList = FXCollections.observableArrayList(warehouseList);
            tableView.setItems(warehouseObservableList);
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    //添加供应商
    @FXML
    private void AddSupplier() {
        Dialog<Pair<String, Map<String, String>>> dialog = new Dialog<>();
        dialog.setTitle("添加供应商");
        dialog.setHeaderText("请输入供应商信息");

        VBox vbox = new VBox(10);
        Label label = new Label("供应商名称:");
        TextField textField = new TextField();
        textField.setPromptText("供应商名称");
        vbox.getChildren().add(label);
        vbox.getChildren().add(textField);

        Label label1 = new Label("联系方式:");
        TextField phoneField = new TextField();
        phoneField.setPromptText("联系方式");
        vbox.getChildren().add(label1);
        vbox.getChildren().add(phoneField);

        Label label2 = new Label("地址:");
        TextField addressField = new TextField();
        addressField.setPromptText("地址");
        vbox.getChildren().add(label2);
        vbox.getChildren().add(addressField);

        Label label3 = new Label("营业执照号:");
        TextField BLField = new TextField();
        BLField.setPromptText("营业执照号");
        vbox.getChildren().add(label3);
        vbox.getChildren().add(BLField);

        ButtonType buttonType = new ButtonType("确认", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(buttonType);
        dialog.getDialogPane().setContent(vbox);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == buttonType) {
                String name = textField.getText().trim();
                String phone = phoneField.getText().trim();
                String BL = BLField.getText().trim();
                Supplier supplier = new Supplier();
                supplier.setName(name);
                supplier.setPhone(phone);
                supplier.setBL(BL);
                supplier.setAddress(addressField.getText().trim());
                return new Pair<>(name, Map.of("phone", phone, "address", addressField.getText().trim(), "BL", BLField.getText().trim()));
            }
            return null;
        });

        Optional<Pair<String, Map<String, String>>> result = dialog.showAndWait();
        result.ifPresent(pair -> {
            String name = pair.getKey();
            Map<String, String> map = pair.getValue();
            String phone = map.get("phone");
            String address = map.get("address");
            String BL = map.get("BL");
            String sql = "INSERT INTO ly_supplier (Supplier_name, Supplier_phone, Supplier_address, Supplier_BL) VALUES (?,?,?,?)";
            try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
                PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, name);
                statement.setString(2, phone);
                statement.setString(3, address);
                statement.setString(4, BL);
                statement.executeUpdate();
                loadSupplierData();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    //修改供应商
    @FXML
    private void UpdateSupplier() {
        Supplier supplier = supplierTable.getSelectionModel().getSelectedItem();
        if (supplier == null) {
            return;
        }
        Dialog<Pair<String, Map<String, String>>> dialog = new Dialog<>();
        dialog.setTitle("修改供应商");
        dialog.setHeaderText("请输入供应商信息");

        VBox vbox = new VBox(10);
        Label label = new Label("供应商名称:");
        TextField textField = new TextField(supplier.getName());
        textField.setPromptText("供应商名称");
        vbox.getChildren().add(label);
        vbox.getChildren().add(textField);

        Label label1 = new Label("联系方式:");
        TextField phoneField = new TextField(supplier.getPhone());
        phoneField.setPromptText("联系方式");
        vbox.getChildren().add(label1);
        vbox.getChildren().add(phoneField);

        Label label2 = new Label("地址:");
        TextField addressField = new TextField(supplier.getAddress());
        addressField.setPromptText("地址");
        vbox.getChildren().add(label2);
        vbox.getChildren().add(addressField);

        Label label3 = new Label("营业执照号:");
        TextField BLField = new TextField(supplier.getBL());
        BLField.setPromptText("营业执照号");
        vbox.getChildren().add(label3);
        vbox.getChildren().add(BLField);

        ButtonType buttonType = new ButtonType("确认", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(buttonType);
        dialog.getDialogPane().setContent(vbox);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == buttonType) {
                String name = textField.getText().trim();
                String phone = phoneField.getText().trim();
                String BL = BLField.getText().trim();
                Supplier supplier1 = new Supplier();
                supplier1.setName(name);
                supplier1.setPhone(phone);
                supplier1.setBL(BL);
                supplier1.setAddress(addressField.getText().trim());
                return new Pair<>(name, Map.of("phone", phone, "address", addressField.getText().trim(), "BL", BLField.getText().trim()));
            }
            return null;
        });

        Optional<Pair<String, Map<String, String>>> result = dialog.showAndWait();
        result.ifPresent(pair -> {
            String name = pair.getKey();
            Map<String, String> map = pair.getValue();
            String phone = map.get("phone");
            String address = map.get("address");
            String BL = map.get("BL");
            String sql = "UPDATE ly_supplier SET Supplier_name = ?, Supplier_phone = ?, Supplier_address = ?, Supplier_BL = ? WHERE Supplier_name = ?";
            try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
                PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, name);
                statement.setString(2, phone);
                statement.setString(3, address);
                statement.setString(4, BL);
                statement.setString(5, supplier.getName());
                statement.executeUpdate();
                loadSupplierData();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
