package com.example.ly_jxc;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Pair;

import java.sql.*;
import java.util.*;

public class CommodityController {
    //退出按钮
    @FXML
    private Button ExitButton;
    @FXML
    private void handleExitButtonAction() {
        Stage stage = (Stage) ExitButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Management-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //数据库连接信息
    private static final String DB_URL = "jdbc:mysql://localhost:3306/inventory-management?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASS = "123456789";

    @FXML
    private TableView<Warehouse> tableView;
    @FXML
    private TableColumn<Warehouse, Integer> id_Column;
    @FXML
    private TableColumn<Warehouse, String> name_Column;
    @FXML
    private TableColumn<Warehouse, String> categoryColumn;
    @FXML
    private TableColumn<Warehouse, Double> purchase_price_Column;
    @FXML
    private TableColumn<Warehouse, Double> selling_price_Column;
    @FXML
    private TableColumn<Warehouse, String> unitPrice_Column;
    @FXML
    private TableColumn<Warehouse, String> supplier_Column;

    //查询
    @FXML
    private Button ShowAllButton;
    @FXML
    private Button QueryButton;
    @FXML
    private TextField Query_content;

    private List<Warehouse> warehouseList = new ArrayList<>();

    //表格绑定
    @FXML
    private void initialize() {
        id_Column.setCellValueFactory(new PropertyValueFactory<>("id"));
        name_Column.setCellValueFactory(new PropertyValueFactory<>("name"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
        purchase_price_Column.setCellValueFactory(new PropertyValueFactory<>("purchase_price"));
        selling_price_Column.setCellValueFactory(new PropertyValueFactory<>("selling_price"));
        unitPrice_Column.setCellValueFactory(new PropertyValueFactory<>("unitPrice"));
        supplier_Column.setCellValueFactory(new PropertyValueFactory<>("supplier"));

        ObservableList<Warehouse> observableWarehouseList = FXCollections.observableArrayList(warehouseList);
        tableView.setItems(observableWarehouseList);
        ShowAllButton.setOnAction(event -> loadDataFromDatabase());
        QueryButton.setOnAction(event -> performQuery());
    }

    //显示所有商品信息
    private void loadDataFromDatabase() {
        String sql = "SELECT Product_id, Product_name, Product_category, Product_purchase_price, Product_selling_price, Pricing_Unit, Product_Supplier FROM ly_warehouse";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            warehouseList.clear();

            while (resultSet.next()) {
                Warehouse warehouse = new Warehouse();
                warehouse.setId(resultSet.getInt("Product_id"));
                warehouse.setName(resultSet.getString("Product_name"));
                warehouse.setCategory(resultSet.getString("Product_category"));
                warehouse.setPurchase_price(resultSet.getDouble("Product_purchase_price"));
                warehouse.setSelling_price(resultSet.getDouble("Product_selling_price"));
                warehouse.setUnitPrice(resultSet.getString("Pricing_Unit"));
                warehouse.setSupplier(resultSet.getString("Product_Supplier"));

                warehouseList.add(warehouse);
            }

            ObservableList<Warehouse> observableWarehouseList = FXCollections.observableArrayList(warehouseList);
            tableView.setItems(observableWarehouseList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //查询商品信息
    private void performQuery() {
        String queryContent = Query_content.getText();   //获取查询内容
        String sql = "SELECT Product_id, Product_name, Product_category, Product_purchase_price, Product_selling_price, Pricing_Unit, Product_Supplier FROM ly_warehouse WHERE Product_name LIKE '%" + queryContent + "%' OR Product_category LIKE '%" + queryContent + "%' OR Product_Supplier LIKE '%" + queryContent + "%'";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            warehouseList.clear();

            while (resultSet.next()) {
                Warehouse warehouse = new Warehouse();
                warehouse.setId(resultSet.getInt("Product_id"));
                warehouse.setName(resultSet.getString("Product_name"));
                warehouse.setCategory(resultSet.getString("Product_category"));
                warehouse.setPurchase_price(resultSet.getDouble("Product_purchase_price"));
                warehouse.setSelling_price(resultSet.getDouble("Product_selling_price"));
                warehouse.setUnitPrice(resultSet.getString("Pricing_Unit"));
                warehouse.setSupplier(resultSet.getString("Product_Supplier"));

                warehouseList.add(warehouse);
            }

            ObservableList<Warehouse> observableWarehouseList = FXCollections.observableArrayList(warehouseList);
            tableView.setItems(observableWarehouseList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //删除
    @FXML
    private void handleDeleteButtonAction() {
        Warehouse selectedWarehouse = tableView.getSelectionModel().getSelectedItem();
        if (selectedWarehouse != null) {
            int productId = selectedWarehouse.getId();
            deleteProductFromDatabase(productId);
            loadDataFromDatabase();
        } else {
            showAlert(Alert.AlertType.INFORMATION, "提示", "请选择一个产品以进行删除。");
        }
    }
    // 从数据库中删除产品
    private void deleteProductFromDatabase(int productId) {
        String sql = "DELETE FROM ly_warehouse WHERE Product_id = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, productId);
            int rowsDeleted = preparedStatement.executeUpdate();

            if (rowsDeleted > 0) {
                showAlert(Alert.AlertType.INFORMATION, "成功", "产品已成功删除。");
            } else {
                showAlert(Alert.AlertType.ERROR, "错误", "删除产品时出错，请重试。");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "错误", "删除产品时发生SQL错误：" + e.getMessage());
        }
    }

    // 添加
    @FXML
    private void handleAddButtonAction() {
        Dialog<Pair<String, Map<String, String>>> dialog = new Dialog<>();
        dialog.setTitle("添加新产品");
        dialog.setHeaderText("请输入新产品的详细信息");

        // 创建对话框内容
        VBox vbox = new VBox(10);
        TextField nameField = new TextField();
        nameField.setPromptText("产品名称");

        TextField categoryField = new TextField();
        categoryField.setPromptText("产品类别");

        TextField purchasePriceField = new TextField();
        purchasePriceField.setPromptText("进货价");

        TextField sellingPriceField = new TextField();
        sellingPriceField.setPromptText("售价");

        TextField unitField = new TextField();
        unitField.setPromptText("售卖方式");

        TextField stockunitField= new TextField();
        stockunitField.setPromptText("库房单位");

        TextField supplierField = new TextField();
        supplierField.setPromptText("供应商");

        vbox.getChildren().addAll(nameField, categoryField, purchasePriceField, sellingPriceField, unitField, stockunitField, supplierField);
        dialog.getDialogPane().setContent(vbox);

        // 设置按钮类型
        ButtonType loginButtonType = new ButtonType("添加", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().setAll(loginButtonType, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                Map<String, String> details = new HashMap<>();
                details.put("类别", categoryField.getText());
                details.put("进货价", purchasePriceField.getText());
                details.put("售价", sellingPriceField.getText());
                details.put("单位", unitField.getText());
                details.put("库房单位", stockunitField.getText());
                details.put("供应商", supplierField.getText());
                return new Pair<>(nameField.getText(), details);
            }
            return null;
        });

        // 显示对话框并等待用户输入
        Optional<Pair<String, Map<String, String>>> result = dialog.showAndWait();
        result.ifPresent(productInfo -> {
            String newName = productInfo.getKey();
            Map<String, String> details = productInfo.getValue();

            Warehouse newWarehouse = new Warehouse();
            newWarehouse.setName(newName);
            newWarehouse.setCategory(details.get("类别"));
            newWarehouse.setPurchase_price(Double.parseDouble(details.get("进货价")));
            newWarehouse.setSelling_price(Double.parseDouble(details.get("售价")));
            newWarehouse.setUnitPrice(details.get("单位"));
            newWarehouse.setUnitStock(details.get("库房单位"));
            newWarehouse.setSupplier(details.get("供应商"));

            addProductToDatabase(newWarehouse);

            loadDataFromDatabase();
        });
    }

    // 将新产品添加到数据库
    private void addProductToDatabase(Warehouse newWarehouse) {
        String sql = "INSERT INTO ly_warehouse (Product_name, Product_category, Product_purchase_price, Product_selling_price, Pricing_Unit, Product_Quantity, unit_of_quantity, Product_Supplier) VALUES (?, ?, ?, ?, ?, ?, ?,?)";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, newWarehouse.getName());
            preparedStatement.setString(2, newWarehouse.getCategory());
            preparedStatement.setDouble(3, newWarehouse.getPurchase_price());
            preparedStatement.setDouble(4, newWarehouse.getSelling_price() );
            preparedStatement.setString(5, newWarehouse.getUnitPrice());
            preparedStatement.setInt(6, 0);
            preparedStatement.setString(7, newWarehouse.getUnitStock());
            preparedStatement.setString(8, newWarehouse.getSupplier());

            // 执行插入操作
            int rowsInserted = preparedStatement.executeUpdate();

            if (rowsInserted > 0) {
                showAlert(Alert.AlertType.INFORMATION, "成功", "产品已成功添加。");
            } else {
                showAlert(Alert.AlertType.ERROR, "错误", "添加产品时出错，请重试。");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "错误", "添加产品时发生SQL错误：" + e.getMessage());
        }
    }

    // 修改
    @FXML
    private void handleUpdateButtonAction() {
        Warehouse selectedWarehouse = tableView.getSelectionModel().getSelectedItem();
        if (selectedWarehouse != null) {
            int productId = selectedWarehouse.getId();
            Dialog<Pair<String, Map<String, String>>> dialog = new Dialog<>();
            dialog.setTitle("修改产品信息");
            dialog.setHeaderText("请输入修改后的产品信息");

            // 创建对话框内容
            VBox vbox = new VBox(10);
            TextField nameField = new TextField();
            nameField.setPromptText("产品名称");
            nameField.setText(selectedWarehouse.getName());

            TextField categoryField = new TextField();
            categoryField.setPromptText("产品类别");
            categoryField.setText(selectedWarehouse.getCategory());

            TextField purchasePriceField = new TextField();
            purchasePriceField.setPromptText("进货价");
            purchasePriceField.setText(Double.toString(selectedWarehouse.getPurchase_price()));

            TextField sellingPriceField = new TextField();
            sellingPriceField.setPromptText("售价");
            sellingPriceField.setText(Double.toString(selectedWarehouse.getSelling_price()));

            TextField unitField = new TextField();
            unitField.setPromptText("售卖方式");
            unitField.setText(selectedWarehouse.getUnitPrice());

            TextField supplierField = new TextField();
            supplierField.setPromptText("供应商");
            supplierField.setText(selectedWarehouse.getSupplier());

            vbox.getChildren().addAll(nameField, categoryField, purchasePriceField, sellingPriceField, unitField,supplierField);
            dialog.getDialogPane().setContent(vbox);

            // 设置按钮类型
            ButtonType loginButtonType = new ButtonType("修改", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().setAll(loginButtonType, ButtonType.CANCEL);

            dialog.setResultConverter(dialogButton -> {
                if (dialogButton == loginButtonType) {
                    Map<String, String> details = new HashMap<>();
                    details.put("类别", categoryField.getText());
                    details.put("进货价", purchasePriceField.getText());
                    details.put("售价", sellingPriceField.getText());
                    details.put("单位", unitField.getText());
                    details.put("供应商", supplierField.getText());
                    return new Pair<>(nameField.getText(), details);
                }
                return null;
            });

            // 显示对话框并等待用户输入
            Optional<Pair<String, Map<String, String>>> result = dialog.showAndWait();
            result.ifPresent(productInfo -> {
                String newName = productInfo.getKey();
                Map<String, String> details = productInfo.getValue();

                Warehouse modifiedWarehouse = new Warehouse();
                modifiedWarehouse.setId(productId);
                modifiedWarehouse.setName(newName);
                modifiedWarehouse.setCategory(details.get("类别"));
                modifiedWarehouse.setPurchase_price(Double.parseDouble(details.get("进货价")));
                modifiedWarehouse.setSelling_price(Double.parseDouble(details.get("售价")));
                modifiedWarehouse.setUnitPrice(details.get("售卖方式"));
                modifiedWarehouse.setSupplier(details.get("供应商"));

                modifyProductInDatabase(modifiedWarehouse);

                loadDataFromDatabase();
            });
        } else {
            showAlert(Alert.AlertType.INFORMATION, "提示", "请选择一个产品以进行修改。");
        }
    }
    // 修改数据库中的产品信息
    private void modifyProductInDatabase(Warehouse modifiedWarehouse) {
        String sql = "UPDATE ly_warehouse SET Product_name = ?, Product_category = ? , Product_purchase_price = ?, Product_selling_price = ?, Pricing_Unit = ?, Product_Supplier = ? WHERE Product_id = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, modifiedWarehouse.getName());
            preparedStatement.setString(2, modifiedWarehouse.getCategory());
            preparedStatement.setDouble(3, modifiedWarehouse.getPurchase_price());
            preparedStatement.setDouble(4, modifiedWarehouse.getSelling_price());
            preparedStatement.setString(5, modifiedWarehouse.getUnitPrice());
            preparedStatement.setString(6, modifiedWarehouse.getSupplier());
            preparedStatement.setInt(7, modifiedWarehouse.getId());

            // 执行更新操作
            int rowsUpdated = preparedStatement.executeUpdate();

            if (rowsUpdated > 0) {
                showAlert(Alert.AlertType.INFORMATION, "成功", "产品信息已成功修改。");
            } else {
                showAlert(Alert.AlertType.ERROR, "错误", "修改产品信息时出错，请重试。");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "错误", "修改产品信息时发生SQL错误：" + e.getMessage());
        }
    }

    // 显示提示信息
    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

}
