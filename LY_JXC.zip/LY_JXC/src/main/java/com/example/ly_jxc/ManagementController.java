package com.example.ly_jxc;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ManagementController {

    //商品管理界面
    @FXML
    private Button CommodityButton;
    @FXML
    private void CommodityButtonOnAction() {
        Stage stage = (Stage) CommodityButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Commodity-management-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //库房管理界面
    @FXML
    private Button WarehouseButton;
    @FXML
    private void WarehouseButtonOnAction() {
        Stage stage = (Stage) WarehouseButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Warehouse-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //采购管理界面
    @FXML
    private Button ProcurementButton;
    @FXML
    private void ProcurementButtonOnAction() {
        Stage stage = (Stage) ProcurementButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Procurement-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //供货商管理界面
    @FXML
    private Button SupplierButton;
    @FXML
    private void SupplierButtonOnAction() {
        Stage stage = (Stage) SupplierButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Supplier-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //退出管理界面
    @FXML
    private Button ExitButton;
    @FXML
    private void handleExitButton(){
        Stage stage = (Stage) ExitButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Start-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
