package com.example.ly_jxc;

public class INOUTRecords {
    private Integer ID;//商品ID
    private String name;//商品名称
    private Double number;//数量
    private String unit;//单位
    private String INOUT;//进出类型
    private String date;//日期
    private double wastage;//损耗
    private String operator;//操作员

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getNumber() {
        return number;
    }

    public void setNumber(Double number) {
        this.number = number;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getINOUT() {
        return INOUT;
    }

    public void setINOUT(String INOUT) {
        this.INOUT = INOUT;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public double getWastage() {
        return wastage;
    }

    public void setWastage(double wastage) {
        this.wastage = wastage;
    }
}
