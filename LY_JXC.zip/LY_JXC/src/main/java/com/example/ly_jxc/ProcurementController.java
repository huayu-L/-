package com.example.ly_jxc;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Pair;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ProcurementController {
    //退出按钮
    @FXML
    private Button ExitButton;
    @FXML
    private void handleExitButtonAction() {
        Stage stage = (Stage) ExitButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Management-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //数据库连接信息
    private static final String DB_URL = "jdbc:mysql://localhost:3306/inventory-management?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASS = "123456789";

    //表格信息
    @FXML
    private TableView<Procurement> tableView;
    @FXML
    private TableColumn<Procurement, Integer> idColumn;
    @FXML
    private TableColumn<Procurement, String> supplier_nameColumn;
    @FXML
    private TableColumn<Procurement, String> dateColumn;
    @FXML
    private TableColumn<Procurement, String> product_nameColumn;
    @FXML
    private TableColumn<Procurement, Double> numberColumn;
    @FXML
    private TableColumn<Procurement, Double> priceColumn;
    @FXML
    private TableColumn<Procurement, Double> total_priceColumn;
    @FXML
    private TableColumn<Procurement, String> statusColumn;

    @FXML
    private Button AllButton;
    @FXML
    private Button FinishedButton;
    @FXML
    private Button UnfinishedButton;
    @FXML
    private Button InvalidButton;

    private List<Procurement> procurements = new ArrayList<>();

    //初始化
    @FXML
    private void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        supplier_nameColumn.setCellValueFactory(new PropertyValueFactory<>("supplier_name"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        product_nameColumn.setCellValueFactory(new PropertyValueFactory<>("product_name"));
        numberColumn.setCellValueFactory(new PropertyValueFactory<>("number"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        total_priceColumn.setCellValueFactory(new PropertyValueFactory<>("total_price"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        ObservableList<Procurement> data = FXCollections.observableArrayList(procurements);
        tableView.setItems(data);
        AllButton.setOnAction(event -> loadDataFromDatabase());
        FinishedButton.setOnAction(event -> FinishedData());
        UnfinishedButton.setOnAction(event -> UnfinishedData());
        InvalidButton.setOnAction(event -> InvalidData());
    }

    //加载数据
    public void loadDataFromDatabase() {
        String  sql = "select purchase_id , supplier_name, purchase_date, purchase_product, purchase_number, unit_price, total_price, status from ly_purchase";
        try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql)) {

            procurements.clear();

            while (resultSet.next()) {
                Procurement p = new Procurement();
                p.setId(resultSet.getInt("purchase_id"));
                p.setSupplier_name(resultSet.getString("supplier_name"));
                p.setDate(resultSet.getString("purchase_date"));
                p.setProduct_name(resultSet.getString("purchase_product"));
                p.setNumber(resultSet.getDouble("purchase_number"));
                p.setPrice(resultSet.getDouble("unit_price"));
                p.setTotal_price(resultSet.getDouble("total_price"));
                p.setStatus(resultSet.getString("status"));
                procurements.add(p);
            }
            ObservableList<Procurement> data = FXCollections.observableArrayList(procurements);
            tableView.setItems(data);

        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //已完成数据
    public void FinishedData() {
        String sql = "select purchase_id , supplier_name, purchase_date, purchase_product, purchase_number, unit_price, total_price, status from ly_purchase where status='已完成'";
        try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql)) {

            procurements.clear();
            while (resultSet.next()) {
                Procurement p = new Procurement();
                p.setId(resultSet.getInt("purchase_id"));
                p.setSupplier_name(resultSet.getString("supplier_name"));
                p.setDate(resultSet.getString("purchase_date"));
                p.setProduct_name(resultSet.getString("purchase_product"));
                p.setNumber(resultSet.getDouble("purchase_number"));
                p.setPrice(resultSet.getDouble("unit_price"));
                p.setTotal_price(resultSet.getDouble("total_price"));
                p.setStatus(resultSet.getString("status"));
                procurements.add(p);
            }
            ObservableList<Procurement> data = FXCollections.observableArrayList(procurements);
            tableView.setItems(data);

            }catch (SQLException e) {
            e.printStackTrace();
            }
    }
    //未完成数据
    public void UnfinishedData() {
        String sql = "select purchase_id , supplier_name, purchase_date, purchase_product, purchase_number, unit_price, total_price, status from ly_purchase where status='待完成'";
        try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql)) {

            procurements.clear();
            while (resultSet.next()) {
                Procurement p = new Procurement();
                p.setId(resultSet.getInt("purchase_id"));
                p.setSupplier_name(resultSet.getString("supplier_name"));
                p.setDate(resultSet.getString("purchase_date"));
                p.setProduct_name(resultSet.getString("purchase_product"));
                p.setNumber(resultSet.getDouble("purchase_number"));
                p.setPrice(resultSet.getDouble("unit_price"));
                p.setTotal_price(resultSet.getDouble("total_price"));
                p.setStatus(resultSet.getString("status"));
                procurements.add(p);
            }
            ObservableList<Procurement> data = FXCollections.observableArrayList(procurements);
            tableView.setItems(data);

        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //作废数据
    public void InvalidData() {
        String sql = "select purchase_id , supplier_name, purchase_date, purchase_product, purchase_number, unit_price, total_price, status from ly_purchase where status='作废'";
        try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql)) {

            procurements.clear();
            while (resultSet.next()) {
                Procurement p = new Procurement();
                p.setId(resultSet.getInt("purchase_id"));
                p.setSupplier_name(resultSet.getString("supplier_name"));
                p.setDate(resultSet.getString("purchase_date"));
                p.setProduct_name(resultSet.getString("purchase_product"));
                p.setNumber(resultSet.getDouble("purchase_number"));
                p.setPrice(resultSet.getDouble("unit_price"));
                p.setTotal_price(resultSet.getDouble("total_price"));
                p.setStatus(resultSet.getString("status"));
                procurements.add(p);
            }
            ObservableList<Procurement> data = FXCollections.observableArrayList(procurements);
            tableView.setItems(data);

        }catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //修改采购单状态
    public void handleModifyButtonAction() {
        Procurement selectedProcurement = tableView.getSelectionModel().getSelectedItem();
        if (selectedProcurement != null) {
            int productId = selectedProcurement.getId();
            Dialog<Pair<String, Map<String, String>>> dialog = new Dialog<>();
            dialog.setTitle("修改采购单状态");
            dialog.setHeaderText("请选择采购单状态");

            VBox vbox = new VBox(10);

            ObservableList<String> statusOptions = FXCollections.observableArrayList(
                    "已完成", "待完成", "作废"
            );
            ComboBox<String> statusComboBox = new ComboBox<>(statusOptions);
            statusComboBox.setValue(selectedProcurement.getStatus());
            statusComboBox.setPromptText("请选择状态");

            vbox.getChildren().addAll(statusComboBox);
            dialog.getDialogPane().setContent(vbox);

            ButtonType modifyButtonType = new ButtonType("修改", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().setAll(modifyButtonType, ButtonType.CANCEL);

            dialog.setResultConverter(dialogButton -> {
                if (dialogButton == modifyButtonType) {
                    String selectedStatus = statusComboBox.getValue();
                    updateProcurementStatus(productId, selectedStatus);
                    loadDataFromDatabase();
                    return new Pair<>(selectedStatus, null);
                }
                return null;
            });

            dialog.showAndWait();
        }
    }
    //修改采购单状态
    private void updateProcurementStatus(int productId, String newStatus) {
        String sql = "UPDATE LY_purchase SET status = ? WHERE purchase_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, productId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //添加采购单
    public void handleAddButtonAction() {
        Dialog<Pair<String, Map<String, String>>> dialog = new Dialog<>();
        dialog.setTitle("添加采购单");
        dialog.setHeaderText("请填写采购单信息");

        VBox vbox = new VBox(10);

        TextField supplierNameField = new TextField();
        supplierNameField.setPromptText("供应商名称");
        vbox.getChildren().add(supplierNameField);

        TextField dateField = new TextField();
        dateField.setPromptText("采购日期");
        vbox.getChildren().add(dateField);

        TextField productNameField = new TextField();
        productNameField.setPromptText("商品名称");
        vbox.getChildren().add(productNameField);

        TextField numberField = new TextField();
        numberField.setPromptText("数量");
        vbox.getChildren().add(numberField);

        TextField unitField = new TextField();
        unitField.setPromptText("单位");
        vbox.getChildren().add(unitField);

        TextField priceField = new TextField();
        priceField.setPromptText("单价");
        vbox.getChildren().add(priceField);

        TextField statusField = new TextField();
        statusField.setPromptText("状态");
        vbox.getChildren().add(statusField);

        dialog.getDialogPane().setContent(vbox);

        ButtonType addButtonType = new ButtonType("添加", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().setAll(addButtonType, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == addButtonType) {
                String supplierName = supplierNameField.getText();
                String date = dateField.getText();
                String productName = productNameField.getText();
                double number = Double.parseDouble(numberField.getText());
                String unitPrice = unitField.getText();
                double price = Double.parseDouble(priceField.getText());
                String status = statusField.getText();
                addProcurement(supplierName, date, productName, number, unitPrice, price, status);
                loadDataFromDatabase();
                return new Pair<>(null, null);
            }
            return null;
        });

        dialog.showAndWait();
    }
    //添加采购单
    private void addProcurement(String supplierName, String date, String productName, double number, String unitPrice, double price, String status) {
        String sql = "INSERT INTO LY_purchase (supplier_name, purchase_date, purchase_product, purchase_number, purchase_unit, unit_price, status) VALUES (? , ? , ? , ?, ?, ?,?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, supplierName);
            pstmt.setString(2, date);
            pstmt.setString(3, productName);
            pstmt.setDouble(4, number);
            pstmt.setString(5, unitPrice);
            pstmt.setDouble(6, price);
            pstmt.setString(7, status);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
