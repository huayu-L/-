package com.example.ly_jxc;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Pair;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

public class WarehouseController {
    //退出按钮
    @FXML
    private Button ExitButton;
    @FXML
    private void handleExitButtonAction() {
        Stage stage = (Stage) ExitButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Management-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //数据库连接信息
    private static final String DB_URL = "jdbc:mysql://localhost:3306/inventory-management?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASS = "123456789";

    //仓库信息表
    @FXML
    private TableView<Warehouse> tableView1;
    @FXML
    private TableColumn<Warehouse, Integer> WarehouseID;
    @FXML
    private TableColumn<Warehouse, String> WarehouseName;
    @FXML
    private TableColumn<Warehouse, String> WarehouseCategory;
    @FXML
    private TableColumn<Warehouse, Double> WarehousePurchasePrice;
    @FXML
    private TableColumn<Warehouse, Double> WarehouseSellingPrice;
    @FXML
    private TableColumn<Warehouse, String> WarehouseUnitPrice;
    @FXML
    private TableColumn<Warehouse, Integer> WarehouseStock;
    @FXML
    private TableColumn<Warehouse, String> WarehouseUnitStock;
    @FXML
    private TableColumn<Warehouse, String> WarehouseSupplier;
    @FXML
    private TableColumn<Warehouse, Double> WarehouseTotalPrice;

    private List<Warehouse> warehouseList = new ArrayList<>();

    //入库
    @FXML
    private TableView<Procurement> tableView2;
    @FXML
    private TableColumn<Procurement, String> ProcurementID;
    @FXML
    private TableColumn<Procurement, String> ProcurementSupplierName;
    @FXML
    private TableColumn<Procurement, String> ProcurementDate;
    @FXML
    private TableColumn<Procurement, String> ProcurementProductName;
    @FXML
    private TableColumn<Procurement, Double> ProcurementNumber;
    @FXML
    private TableColumn<Procurement, Double> ProcurementPrice;
    @FXML
    private TableColumn<Procurement, Double> ProcurementTotalPrice;

    private List<Procurement> procurementList = new ArrayList<>();

    //出入库信息表
    @FXML
    private TableView<INOUTRecords> tableView3;
    @FXML
    private TableColumn<INOUTRecords, Integer> INOUTID;
    @FXML
    private TableColumn<INOUTRecords, String> INOUTName;
    @FXML
    private TableColumn<INOUTRecords, Double> INOUTNumber;
    @FXML
    private TableColumn<INOUTRecords, String> INOUTUnit;
    @FXML
    private TableColumn<INOUTRecords, String> INOUTINOUT;
    @FXML
    private TableColumn<INOUTRecords, String> INOUTDate;
    @FXML
    private TableColumn<INOUTRecords, Double> INOUTwastage;
    @FXML
    private TableColumn<INOUTRecords, String> INOUTOperator;

    private List<INOUTRecords> inoutRecordsList = new ArrayList<>();

    //初始化三个表格
    public void initialize() {
        //库房信息表
       WarehouseID.setCellValueFactory(new PropertyValueFactory<>("id"));
       WarehouseName.setCellValueFactory(new PropertyValueFactory<>("name"));
       WarehouseCategory.setCellValueFactory(new PropertyValueFactory<>("category"));
       WarehousePurchasePrice.setCellValueFactory(new PropertyValueFactory<>("purchase_price"));
       WarehouseSellingPrice.setCellValueFactory(new PropertyValueFactory<>("selling_price"));
       WarehouseUnitPrice.setCellValueFactory(new PropertyValueFactory<>("unitPrice"));
       WarehouseStock.setCellValueFactory(new PropertyValueFactory<>("stock"));
       WarehouseUnitStock.setCellValueFactory(new PropertyValueFactory<>("unitStock"));
       WarehouseSupplier.setCellValueFactory(new PropertyValueFactory<>("supplier"));
       WarehouseTotalPrice.setCellValueFactory(new PropertyValueFactory<>("total_price"));

       ObservableList<Warehouse> warehouseObservableList = FXCollections.observableList(warehouseList);
       tableView1.setItems(warehouseObservableList);
       WarehouseloadData();

       //入库信息表
        ProcurementID.setCellValueFactory(new PropertyValueFactory<>("id"));
       ProcurementSupplierName.setCellValueFactory(new PropertyValueFactory<>("supplier_name"));
       ProcurementDate.setCellValueFactory(new PropertyValueFactory<>("date"));
       ProcurementProductName.setCellValueFactory(new PropertyValueFactory<>("product_name"));
       ProcurementNumber.setCellValueFactory(new PropertyValueFactory<>("number"));
       ProcurementPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
       ProcurementTotalPrice.setCellValueFactory(new PropertyValueFactory<>("total_price"));

       ObservableList<Procurement> procurementObservableList = FXCollections.observableList(procurementList);
       tableView2.setItems(procurementObservableList);
       ProcurementDate();

       //出入库信息表
        INOUTID.setCellValueFactory(new PropertyValueFactory<>("ID"));
        INOUTName.setCellValueFactory(new PropertyValueFactory<>("name"));
        INOUTNumber.setCellValueFactory(new PropertyValueFactory<>("number"));
        INOUTUnit.setCellValueFactory(new PropertyValueFactory<>("unit"));
        INOUTINOUT.setCellValueFactory(new PropertyValueFactory<>("INOUT"));
        INOUTDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        INOUTwastage.setCellValueFactory(new PropertyValueFactory<>("wastage"));
        INOUTOperator.setCellValueFactory(new PropertyValueFactory<>("operator"));

        ObservableList<INOUTRecords> inoutRecordsObservableList = FXCollections.observableList(inoutRecordsList);
        tableView3.setItems(inoutRecordsObservableList);
        INOUTloadData();
    }

    //加载仓库信息
    private void WarehouseloadData() {
        String sql = "SELECT Product_id, Product_name, Product_category, Product_purchase_price, Product_selling_price, Pricing_Unit, Product_quantity, Unit_of_quantity, Product_Supplier FROM ly_warehouse";
        try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql)) {

            warehouseList.clear();
            while (resultSet.next()) {
                double purchasePrice = resultSet.getDouble("Product_purchase_price");
                int quantity = resultSet.getInt("Product_quantity");

                Warehouse warehouse = new Warehouse();
                warehouse.setId(resultSet.getInt("Product_id"));
                warehouse.setName(resultSet.getString("Product_name"));
                warehouse.setCategory(resultSet.getString("Product_category"));
                warehouse.setPurchase_price(resultSet.getDouble("Product_purchase_price"));
                warehouse.setSelling_price(resultSet.getDouble("Product_selling_price"));
                warehouse.setUnitPrice(resultSet.getString("Pricing_Unit"));
                warehouse.setStock(resultSet.getInt("Product_quantity"));
                warehouse.setUnitStock(resultSet.getString("Unit_of_quantity"));
                warehouse.setSupplier(resultSet.getString("Product_Supplier"));
                warehouse.setTotal_price(purchasePrice * quantity);

                warehouseList.add(warehouse);
            }

        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    //加载入库信息
    private void ProcurementDate(){
        String sql = "SELECT purchase_id, supplier_name, purchase_date, purchase_product, purchase_number, unit_price, total_price FROM ly_purchase where status = '已完成'";
        try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql)) {

            procurementList.clear();

            while (resultSet.next()) {
                Procurement procurement = new Procurement();
                procurement.setId(resultSet.getInt("purchase_id"));
                procurement.setSupplier_name(resultSet.getString("supplier_name"));
                procurement.setDate(resultSet.getString("purchase_date"));
                procurement.setProduct_name(resultSet.getString("purchase_product"));
                procurement.setNumber(resultSet.getDouble("purchase_number"));
                procurement.setPrice(resultSet.getDouble("unit_price"));
                procurement.setTotal_price(resultSet.getDouble("total_price"));

                procurementList.add(procurement);
            }
        }catch(Exception e){
                e.printStackTrace();
        }
    }

    //加载出入库信息
    private void INOUTloadData() {
        String sql = "SELECT * from ly_in_out_records";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            inoutRecordsList.clear();
            while (resultSet.next()) {
                INOUTRecords inoutRecords = new INOUTRecords();
                inoutRecords.setID(resultSet.getInt("Bound_id"));
                inoutRecords.setName(resultSet.getString("Bound_product"));
                inoutRecords.setNumber(resultSet.getDouble("Bound_number"));
                inoutRecords.setUnit(resultSet.getString("unit_of_quantity"));
                inoutRecords.setINOUT(resultSet.getString("IN_OR_OUT"));
                inoutRecords.setDate(resultSet.getString("Bound_Date"));
                inoutRecords.setWastage(resultSet.getDouble("Bound_wastage"));
                inoutRecords.setOperator(resultSet.getString("Bound_Operator"));
                inoutRecordsList.add(inoutRecords);
            }

        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 出库
    @FXML
    private void handleOutButtonAction() {
        Warehouse selectedWarehouse = tableView1.getSelectionModel().getSelectedItem();
        if (selectedWarehouse != null) {
            int productId = selectedWarehouse.getId();
            Dialog<Pair<String, Integer>> dialog = new Dialog<>();
            dialog.setTitle("出库");
            dialog.setHeaderText("请输入出库数量");

            VBox vbox = new VBox(10);
            Label nameLabel = new Label("产品名称: " + selectedWarehouse.getName());
            TextField numberField = new TextField();
            numberField.setPromptText("出库数量");

            vbox.getChildren().addAll(nameLabel, numberField);
            dialog.getDialogPane().setContent(vbox);

            // 设置按钮类型
            ButtonType outButtonType = new ButtonType("出库", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().setAll(outButtonType, ButtonType.CANCEL);


            dialog.setResultConverter(dialogButton -> {
                if (dialogButton == outButtonType) {
                    try {
                        int outNumber = Integer.parseInt(numberField.getText().trim());
                        if (outNumber > selectedWarehouse.getStock()) {
                            showAlert(Alert.AlertType.ERROR, "错误", "出库数量必须小于等于当前库存。");
                        }
                        return new Pair<>(selectedWarehouse.getName(), outNumber);
                    } catch (NumberFormatException e) {
                        showAlert(Alert.AlertType.ERROR, "错误", e.getMessage());
                        return null;
                    }
                }
                return null;
            });

            Optional<Pair<String, Integer>> result = dialog.showAndWait();
            result.ifPresent(pair -> {
                String productName = pair.getKey();
                String Unit = selectedWarehouse.getUnitStock();
                int outNumber = pair.getValue();
                if (updateStock1(productId, -outNumber)) {
                    OutRecord(productName, outNumber, Unit);// 添加出库信息
                    showAlert(Alert.AlertType.INFORMATION, "成功", productName + " 已成功出库 " + outNumber + " 个。");
                    WarehouseloadData();// 刷新表格数据
                } else {
                    showAlert(Alert.AlertType.ERROR, "错误", "出库失败，请稍后再试。");
                }
            });
        } else {
            showAlert(Alert.AlertType.INFORMATION, "提示", "请选择一个产品以进行出库。");
        }
    }
    // 更新库存数量
    private boolean updateStock1(int productId, int change) {
        String sql = "UPDATE ly_warehouse SET Product_quantity = Product_quantity + ? WHERE Product_id = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, change);
            statement.setInt(2, productId);
            int affectedRows = statement.executeUpdate();
            return affectedRows > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    //添加出库信息
    private void OutRecord(String productName, int outNumber, String unit) {
        String sql = "INSERT INTO ly_in_out_records (Bound_product, Bound_number, unit_of_quantity, IN_OR_OUT,Bound_Date,Bound_Operator) VALUES (?,?,?,?,?,?)";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, productName);
            statement.setInt(2, outNumber);
            statement.setString(3, unit);
            statement.setString(4, "出库");
            statement.setString(5, new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
            statement.setString(6, "ADMIN");
            statement.executeUpdate();
            INOUTloadData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //刷新订单信息
    @FXML
    private void handleRefreshButtonction() {
        ProcurementDate();
    }
    //入库
    @FXML
    private void handleInButtonAction() {
        Procurement selectedProcurement = tableView2.getSelectionModel().getSelectedItem();
        if (selectedProcurement != null) {
            int procurmentId = selectedProcurement.getId();
            Dialog<Pair<String, Integer>> dialog = new Dialog<>();
            dialog.setTitle("入库");
            dialog.setHeaderText("请输入入库数量");

            VBox vbox = new VBox(10);
            Label nameLabel = new Label("产品名称: " + selectedProcurement.getProduct_name());
            TextField numberField = new TextField();
            numberField.setPromptText("入库数量");
            vbox.getChildren().addAll(nameLabel, numberField);
            dialog.getDialogPane().setContent(vbox);

            // 设置按钮类型
            ButtonType inButtonType = new ButtonType("入库", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().setAll(inButtonType, ButtonType.CANCEL);

            dialog.setResultConverter(dialogButton -> {
                if (dialogButton == inButtonType) {
                    try{
                        int inNumber = Integer.parseInt(numberField.getText().trim());
                        if (inNumber < 0) {
                            showAlert(Alert.AlertType.ERROR, "错误", "入库数量必须大于0。");
                        }
                        return new Pair<>(selectedProcurement.getProduct_name(), inNumber);
                    }catch (NumberFormatException e){
                        showAlert(Alert.AlertType.ERROR, "错误", e.getMessage());
                        return null;
                    }
                }
                return null;
            });
            Optional<Pair<String, Integer>> result = dialog.showAndWait();
            result.ifPresent(pair -> {
                String productName = pair.getKey();
                String Unit = selectedProcurement.getUnit();
                double oldNumber = selectedProcurement.getNumber();
                int inNumber = pair.getValue();
                if (updateStock2(productName, inNumber)) {
                    InRecord(procurmentId,productName, oldNumber, inNumber, Unit);// 添加入库信息
                    showAlert(Alert.AlertType.INFORMATION, "成功", productName + " 已成功入库 " + inNumber + " 个。");
                    WarehouseloadData();
                    ProcurementDate();
                    INOUTloadData();
                } else {
                    showAlert(Alert.AlertType.ERROR, "错误", "入库失败，请稍后再试。");
                }
            });
        }else{
            showAlert(Alert.AlertType.INFORMATION, "提示", "请选择一个订单以进行入库。");
        }
    }
    //更新库存数量
    private boolean updateStock2(String productName, int inNumber) {
        String sql = "UPDATE ly_warehouse SET Product_quantity = Product_quantity + ? WHERE Product_name = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, inNumber);
            statement.setString(2, productName);
            int affectedRows = statement.executeUpdate();
            return affectedRows > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    //添加入库信息和更改订单状态
    private void InRecord(int procurmentId,String productName,double oldNumber, int inNumber, String unit) {
        String sql1 = "Insert into ly_in_out_records (Bound_product, Bound_number, unit_of_quantity, IN_OR_OUT,Bound_Date,Bound_wastage,Bound_Operator) values (?,?,?,?,?,?,?)";
        String sql2 = "Update ly_purchase set status = '已入库' where purchase_id = ?";
        try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
            PreparedStatement statement1 = connection.prepareStatement(sql1);
            PreparedStatement statement2 = connection.prepareStatement(sql2)){

            statement1.setString(1, productName);
            statement1.setInt(2, inNumber);
            statement1.setString(3, unit);
            statement1.setString(4, "入库");
            statement1.setString(5, new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
            statement1.setDouble(6, oldNumber - inNumber);
            statement1.setString(7, "ADMIN");

            statement2.setInt(1, procurmentId);

            statement1.executeUpdate();
            statement2.executeUpdate();

        }catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 显示提示信息
    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
