package com.example.ly_jxc;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class StartController {
    @FXML
    private Button LoginButton;
    @FXML
    private Button RegisterButton;

    //退出按钮，退出程序
    @FXML
    private void handleExited(){
        System.exit(0);
    }

    //登录按钮，跳转到登录页面
    @FXML
    private void handleLoginButtonAction(){
        Stage stage = (Stage) LoginButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //注册按钮，跳转到注册页面
    @FXML
    private void handleRegisterButtonAction(){
        Stage stahe = (Stage) RegisterButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Register-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stahe.setScene(scene);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}