package com.example.ly_jxc;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RegisterController {
    @FXML
    private TextField usernameField;
    @FXML
    private TextField passwordField;
    @FXML
    private TextField phoneField;
    @FXML
    private Button registerButton;

    // 数据库相关变量
    private static final String DB_URL = "jdbc:mysql://localhost:3306/inventory-management?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASS = "123456789";

    // 注册按钮事件
    @FXML
    private void handleregisterButton(){
        String username = usernameField.getText();
        String password = passwordField.getText();
        String phone = phoneField.getText();
        // 数据库操作
        if(checkUsername(username)==false){
            Insert_User(username,password,phone);
            showAlert(Alert.AlertType.INFORMATION, "注册成功", "恭喜您注册成功，请登录");

            usernameField.clear();
            passwordField.clear();
            phoneField.clear();
            Stage stage = (Stage) registerButton.getScene().getWindow();
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Start-view.fxml"));
                Parent root = loader.load();
                Scene scene = new Scene(root);
                stage.setScene(scene);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else{
            showAlert(Alert.AlertType.ERROR, "注册失败", "用户名已存在");
        }
    }

    // 检查用户名是否存在
    private boolean checkUsername(String username){
        try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM ly_user WHERE User_name = ?")) {

            pstmt.setString(1, username);

            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    // 向数据库中插入用户信息
    private void Insert_User(String username,String password,String phone){
        try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO ly_user(User_name,User_password,User_phone,permission) VALUES(?,?,?,'USER')")) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, phone);

            pstmt.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    // 显示提示信息
    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    @FXML
    private Button CancelButton;
    @FXML
    private void handleCancelButton(){
        Stage stage = (Stage) CancelButton.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Start-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
